-- AlterTable
ALTER TABLE "User" ALTER COLUMN "created_at" DROP DEFAULT;
